megacli and megasimplesync
==========================

Using these projects, you can build MEGAcli and MEGAsimplesync on any platform.
The dependencies are the same as the SDK, and additionally `readline` for `megacli`.
You can get precompiled binaries of the dependencies for Windows here:
https://mega.nz/#!tldz0LoS!y4QxNuUIf_wXA0eId7lnrQheezhtyatvKdpFDC1p_2w

It's needed to uncompress them on `mega\bindings\qt`