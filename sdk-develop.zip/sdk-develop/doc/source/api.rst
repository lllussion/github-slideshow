********
MEGA API
********

XXX Make sure to prepend all files with the following directive:

``/**``
`` * @file``
`` */``

Basic API Settings and Includes (``mega``)
==========================================

.. doxygenfile:: mega.h


Client API (``megaclient``)
===========================

.. doxygenfile:: mega/megaclient.h
