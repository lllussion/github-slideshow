# MEGAcmd - Command Line Interactive and Scriptable Application

Project moved to https://github.com/meganz/megacmd
